#  🌌🌎🌙 Interactive solar system

A Pen created on CodePen.io. Original URL: [https://codepen.io/lazercaveman/pen/aRoLaB](https://codepen.io/lazercaveman/pen/aRoLaB).

This Pen is showing a little, interactive solar system. I played a little with animations, pseudo elements, fonts (as images), drop-shadows, and so on. On the bottom of the pen there is a little navigation bar which can be used to trigger events on the solar system.
