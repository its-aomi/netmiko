# Sass Solar system 

A Pen created on CodePen.io. Original URL: [https://codepen.io/hugo/pen/AwPGwL](https://codepen.io/hugo/pen/AwPGwL).

Sass based CSS solar system. The orbiting times are proportional to each other.